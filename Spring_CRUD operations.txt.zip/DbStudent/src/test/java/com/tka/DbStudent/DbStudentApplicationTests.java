package com.tka.DbStudent;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbStudentApplicationTests {

	@Test
	void contextLoads() {
	}

}
