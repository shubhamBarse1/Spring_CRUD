package com.tka.DbStudent;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbStudentApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbStudentApplication.class, args);
		System.out.println("Application Started...");
	}
	
}
