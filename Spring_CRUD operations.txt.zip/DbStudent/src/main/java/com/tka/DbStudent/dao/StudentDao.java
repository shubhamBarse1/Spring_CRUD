package com.tka.DbStudent.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.DbStudent.entity.Student;

@Repository
public class StudentDao {
    
	@Autowired
	SessionFactory factory;
	
	public String insertdata(Student std) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		session.persist(std);
		session.getTransaction().commit();
		session.close();
		return"data is inserted...";
		
	}
	public String updatedata(Student std,int id) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		Student ss=session.get(Student.class,id);
		ss.setName(std.getName());
		ss.setMobileno(std.getMobileno());
		ss.setEmail_id(std.getEmail_id());
		ss.setBranch(std.getBranch());
		
		session.merge(ss);
		session.getTransaction().commit();
		session.close();
		return"data is updated...";
		
		
	}
	public String deletedata(int id) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		Student ss=session.get(Student.class, id);
		session.remove(ss);
		session.getTransaction().commit();
		session.close();
		return"data is deleted...";
	}
	
	public Student getparticulardata(int id) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		String hqlQuery="from Student where id=:myid";
		Query<Student> query=session.createQuery(hqlQuery,Student.class);
		query.setParameter("myid",id);
		Student s=query.uniqueResult();
		
		session.getTransaction().commit();
		session.close();
		return s;
		
	}
	public List<Student> getAlldata() {
		Session session = factory.openSession();
		session.beginTransaction();
		
		String hqlQuery="from Student";
		
		Query<Student> query=session.createQuery(hqlQuery,Student.class);
		List<Student> list =query.list();
		session.getTransaction().commit();
		session.close();
		return list;
	}
}
