package com.tka.DbStudent.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tka.DbStudent.entity.Student;
import com.tka.DbStudent.service.StudentService;

@RestController
@RequestMapping("/api")
public class StudentController {
    
	@Autowired
	StudentService service;
	
	@PostMapping("/savedata")
	public String insertdata(@RequestBody Student std) {
		String msg=service.insertdata(std);
		return msg;	
	}
	@PutMapping("/updatedata/{id}")
	public String updatedata(@PathVariable int id,@RequestBody Student std) {
		String msg=service.updatedata(std, id);
		return msg;
		
	}
	@DeleteMapping("/deletedata/{id}")
	public String deletedata(@PathVariable int id) {
		String msg=service.deletedata(id);
		return msg;
	}
	@GetMapping("/getsingledata/{id}")
	public Student getparticulardata(@PathVariable int id) {
		Student s=service.getparticulardata(id);
		return s;
	}
	@GetMapping("/getallData")
	public List<Student> getAlldata() {
		List<Student>list=service.getAlldata();
		return list;
	}
}
