package com.tka.DbStudent.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.DbStudent.dao.StudentDao;
import com.tka.DbStudent.entity.Student;

@Service
public class StudentService {
    
	@Autowired
	StudentDao dao;
	
	public String insertdata(Student std) {
		String msg=dao.insertdata(std);
		return msg;
		}
	public String updatedata(Student std,int id) {
		String msg=dao.updatedata(std, id);
		return msg;
	}
	public String deletedata(int id) {
		String msg =dao.deletedata(id);
		return msg;
	}
	public Student getparticulardata(int id) {
		Student s=dao.getparticulardata(id);
		return s;
		
	}
	public List<Student> getAlldata() {
		List<Student>list=dao.getAlldata();
		return list;
	}
}
