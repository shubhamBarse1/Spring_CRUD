package com.tka.DbCountry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbCountryApplicationTests {

	@Test
	void contextLoads() {
	}

}
