package com.tka.DbCountry.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tka.DbCountry.entity.Country;
import com.tka.DbCountry.service.CountryService;

@RestController
@RequestMapping("/api")
public class CountryController {
    
	@Autowired
	CountryService service;
	
	@PostMapping("/savedata")
	public String insertdata(@RequestBody Country con) {
		String msg=service.insertdata(con);
		return msg;
	}
	
	@PutMapping("/updatedata/{id}")
	public String updatedata(@PathVariable int id,@RequestBody Country con) {
		String msg=service.updatedata(con, id);
		return msg;
	}
	
	@DeleteMapping("/deletedata/{id}")
	public String deletedata(@PathVariable int id) {
		String msg = service.deletedata(id);
		return msg;
	}
	@GetMapping("/getonedata/{id}")
	public Country getparticulardata(@PathVariable int id) {
		Country c=service.getparticulardata(id);
		return c;
	}
	
	@GetMapping("/getAlldata")
	public java.util.List<Country> getAlldata() {
	  java.util.List<Country> list = service.getAlldata();
		return list;
	}
}
