package com.tka.DbCountry.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.DbCountry.dao.CountryDao;
import com.tka.DbCountry.entity.Country;

@Service
public class CountryService {
    
	@Autowired
	CountryDao dao;
	
	public String insertdata(Country con) {
	 String msg = dao.insertdata(con);
	 return msg;
		
	}
	
	public String updatedata(Country con, int id) {
		String msg = dao.updatedata(con, id);
		return msg;
		
	}
	public String deletedata(int id) {
		String msg=dao.deletedata(id);
		return msg;
	}
	
	public Country getparticulardata(int id) {
	    Country c= dao.getparticulardata(id);
		return c;
	}
	
	public List<Country> getAlldata() {
		List<Country> list=dao.getAlldata();
		return list;
	}
	
}
