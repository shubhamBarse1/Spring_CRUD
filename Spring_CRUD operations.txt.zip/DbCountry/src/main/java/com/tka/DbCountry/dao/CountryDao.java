package com.tka.DbCountry.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.DbCountry.entity.Country;

import jakarta.persistence.Query;

@Repository
public class CountryDao {
    
	@Autowired
	SessionFactory factory;
	
	public String insertdata(Country con) {
	 Session session =factory.openSession();
	 session.beginTransaction();
	 
	 session.persist(con);
	 session.getTransaction().commit();
	 session.close();
	 return "data is inserted...";
	 }
	
   public String updatedata(Country con,int id) {
	   Session session = factory.openSession();
	   session.beginTransaction();
	   
	  Country c= session.get(Country.class,id);
	  c.setCname(con.getCname());
	  session.merge(c);
	  session.getTransaction().commit();
	  session.close();
	  return "data is updated...";
   }
   
   public String deletedata(int id) {
	   
	  Session session= factory.openSession();
	  session.beginTransaction();
	  
	  Country c = session.get(Country.class,id);
	  session.remove(c);
	  session.getTransaction().commit();
	  session.close();
	  return"data is deleted...";
   }
   
   public Country getparticulardata(int id) {
	   Session session = factory.openSession();
	   session.beginTransaction();
	   
	   String hqlQuery="from Country where id=:myid";
	   
	  Query query= session.createQuery(hqlQuery,Country.class);
	  query.setParameter("myid",id);
	  Country c=(Country) query.getSingleResult();
	  session.getTransaction().commit();
	  session.close();
	  return c;
   }
   
   public List<Country> getAlldata() {
	  Session session= factory.openSession();
	  session.beginTransaction();
	  
	  String hqlQuery="from Country";
	  
	 org.hibernate.query.Query<Country>query =session.createQuery(hqlQuery,Country.class);
	 List<Country> list= query.list();
	
	 session.getTransaction().commit();
	 session.close();
	 return list;
	 
   }
	
}
