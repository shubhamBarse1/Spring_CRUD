package com.tka.DbFamily;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbFamilyApplicationTests {

	@Test
	void contextLoads() {
	}

}
