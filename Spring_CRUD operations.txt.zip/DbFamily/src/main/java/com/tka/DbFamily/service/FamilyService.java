package com.tka.DbFamily.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tka.DbFamily.dao.FamilyDao;
import com.tka.DbFamily.entity.Family;

@Service
public class FamilyService {
	
    @Autowired
	FamilyDao dao;
    
    public String insertdata(Family fam) {
    	String msg=dao.insertdata(fam);
    	return msg;	
    }
    
    public String updatedata(Family fam,int id) {
    	String msg=dao.updatedata(fam, id);
    	return msg;
    	
    }
    public String deletedata(int id) {
    	String msg =dao.deletedata(id);
    	return msg;
    	
    }
    
    public Family getparticulardata(int id) {
    	Family f= dao.getparticulardata(id);
    	return f;
    }
    public List<Family> getAlldata() {
    	List<Family> list=dao.getAlldata();
    	return list;
    	}
}
