package com.tka.DbFamily;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DbFamilyApplication {

	public static void main(String[] args) {
		SpringApplication.run(DbFamilyApplication.class, args);
		
		System.out.println("Application started...");
	}

}
