package com.tka.DbFamily.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.tka.DbFamily.entity.Family;

@Repository
public class FamilyDao {

	@Autowired
	SessionFactory factory;
	
	public String insertdata(Family fam) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		session.persist(fam);
		session.getTransaction().commit();
		session.close();
		return"data is inserted...";
	}
	
	public String updatedata(Family fam,int id) {
		
		Session session = factory.openSession();
		session.beginTransaction();
		
		Family f= session.get(Family.class, id);
		f.setAdhar_no(fam.getAdhar_no());
		f.setDriving_L_No(fam.getDriving_L_No());
		f.setPan_No(fam.getPan_No());
		
		session.merge(f);
		session.getTransaction().commit();
		session.close();
		return"data is updated...";
		
	}
	public String deletedata(int id) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		Family ff=session.get(Family.class, id);
	    
		session.remove(ff);
		session.getTransaction().commit();
		session.close();
		return"data is deleted...";
		
	}
	public Family getparticulardata(int id) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		String hqlQuery ="from Family where id=:myid";
		Query<Family> query = session.createQuery(hqlQuery,Family.class);
		query.setParameter("myid",id);
		
		Family f=query.uniqueResult();
		
		session.getTransaction().commit();
		session.close();
		return f;
	}
	public List<Family> getAlldata() {
		
		Session session = factory.openSession();
		session.beginTransaction();
		
		String hqlQuery="From Family";
		
		Query<Family> query= session.createQuery(hqlQuery,Family.class);
	    List<Family> list = query.list();
	    
	    session.getTransaction().commit();
	    session.close();
	    return list;
	}
}
