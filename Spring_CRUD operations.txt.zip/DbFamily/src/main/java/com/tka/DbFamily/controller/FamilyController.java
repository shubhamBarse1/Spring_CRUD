package com.tka.DbFamily.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.tka.DbFamily.entity.Family;
import com.tka.DbFamily.service.FamilyService;

@RestController
@RequestMapping("/api")
public class FamilyController {
    
	@Autowired
	FamilyService service;
	
	@PostMapping("/savedata")
	public String insertdata(@RequestBody Family fam) {
    String msg = service.insertdata(fam);
    return msg;
	}
	@PutMapping("/updatedata/{id}")
	public String updatedata(@PathVariable int id, @RequestBody Family fam) {
		String msg = service.updatedata(fam, id);
		return msg;	
	}
	@DeleteMapping("/deletedata/{id}")
	public String deletedata(@PathVariable int id) {
		String msg = service.deletedata(id);
		return msg;
	}
	@GetMapping("/getsingledata/{id}")
	public Family getparticulardata(@PathVariable int id) {
	   Family f=service.getparticulardata(id);
	   return f;
		
	}
	@GetMapping("/getalldata")
	public List<Family> getAlldata() {
		List<Family> list=service.getAlldata();
		return list;
	}
}
