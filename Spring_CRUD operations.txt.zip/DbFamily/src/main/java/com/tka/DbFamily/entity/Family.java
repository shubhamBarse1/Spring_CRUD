package com.tka.DbFamily.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Family {
    
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	int id;
	@Column(unique = true)
	String adhar_no;
	@Column(unique = true)
	String pan_No;
	@Column(unique = true)
	String Driving_L_No;
	
	
	public Family() {
		
	}
	
	
	public Family(String adhar_no, String pan_No, String driving_L_No) {
		super();
		this.adhar_no = adhar_no;
		this.pan_No = pan_No;
		Driving_L_No = driving_L_No;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAdhar_no() {
		return adhar_no;
	}
	public void setAdhar_no(String adhar_no) {
		this.adhar_no = adhar_no;
	}
	public String getPan_No() {
		return pan_No;
	}
	public void setPan_No(String pan_No) {
		this.pan_No = pan_No;
	}
	public String getDriving_L_No() {
		return Driving_L_No;
	}
	public void setDriving_L_No(String driving_L_No) {
		Driving_L_No = driving_L_No;
	}
	
	
	@Override
	public String toString() {
		return "Family [id=" + id + ", adhar_no=" + adhar_no + ", pan_No=" + pan_No + ", Driving_L_No=" + Driving_L_No
				+ "]";
	}
	
}
