package com.tka.DbAddress;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbAddressApplicationTests {

	@Test
	void contextLoads() {
	}

}
