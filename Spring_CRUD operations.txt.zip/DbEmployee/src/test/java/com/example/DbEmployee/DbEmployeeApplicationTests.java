package com.example.DbEmployee;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbEmployeeApplicationTests {

	@Test
	void contextLoads() {
	}

}
