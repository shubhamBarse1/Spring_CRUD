package com.example.DbEmployee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.DbEmployee.dao.EmployeeDao;
import com.example.DbEmployee.entity.Employee;

@Service
public class EmployeeService {
    
	@Autowired
	EmployeeDao dao;
	
	public String insertdata(Employee emp) {
		String msg = dao.insertdata(emp);
		return msg;
		
	}
	
	public String updatedata(Employee emp, int id) {
		String msg = dao.updatedata(emp, id);
		return msg;
	}
	
	public String deletedata(int id) {
		String msg = dao.deletedata(id);
		return msg;
		
	}
	
	public Employee getparticulardata(int id) {
	   Employee e=	dao.getparticulardata(id);
		return e;
	}
	
	public List<Employee> getAlldata() {
		List<Employee> list=dao.getAlldata();
		return list;
	}
	
}
