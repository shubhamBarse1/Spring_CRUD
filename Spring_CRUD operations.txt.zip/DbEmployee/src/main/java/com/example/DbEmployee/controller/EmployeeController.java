package com.example.DbEmployee.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.DbEmployee.entity.Employee;
import com.example.DbEmployee.service.EmployeeService;

@RestController
@RequestMapping("/api")
public class EmployeeController {
	
    @Autowired
	EmployeeService service;
	
    @PostMapping("/savedata")
    public String insertdata(@RequestBody Employee emp) {
    	String msg = service.insertdata(emp);
    	return msg;
    }
    
    @PutMapping("/updatedata/{id}")
    public String updatedata(@PathVariable int id,@RequestBody Employee emp) {
    	String msg=service.updatedata(emp, id);
    	return msg;
    }
    
    @DeleteMapping("/deletedata/{id}")
    public String deletedata(@PathVariable int id) {
    	String msg = service.deletedata(id);
    	return msg;
    }
    
    @GetMapping("/getonedata/{id}")
    public Employee getparticulardata(@PathVariable int id) {
    	Employee e =service.getparticulardata(id);
    	return e;
    	
    }
    @GetMapping("/getAllData")
    public java.util.List<Employee> getAlldata(){
    	java.util.List<Employee>list=service.getAlldata();
    	return list;
    }
}
