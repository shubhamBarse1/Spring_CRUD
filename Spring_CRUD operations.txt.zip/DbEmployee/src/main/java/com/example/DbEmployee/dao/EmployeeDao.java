package com.example.DbEmployee.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.example.DbEmployee.entity.Employee;

@Repository
public class EmployeeDao {
    
	@Autowired
	SessionFactory factory;
	
	public String insertdata(Employee emp) {
		
		Session session = factory.openSession();
		session.beginTransaction();
		session.persist(emp);
		session.getTransaction().commit();
		session.close();
		return"data is inserted...";
	}
	
	public String updatedata(Employee emp, int id) {
		
		Session session= factory.openSession();
		session.beginTransaction();
		
		Employee Dbrecord = session.get(Employee.class, id);
		
		Dbrecord.setName(emp.getName());
		Dbrecord.setEmailid(emp.getEmailid());
		Dbrecord.setMoblineno(emp.getMoblineno());
		
		session.merge(Dbrecord);
		session.getTransaction().commit();
		session.close();
		return"data is updated...";
		
	}

	public String deletedata(int id) {
		
		Session session = factory.openSession();
		session.beginTransaction();
		
		Employee d= session.get(Employee.class,id);
		session.remove(d);
		session.getTransaction().commit();
		session.close();
		
		return "data is deleted...";
	}
	
	public Employee getparticulardata(int id) {
		Session session = factory.openSession();
		session.beginTransaction();
		
		String hqlQuery ="from Employee where id=:myid";
		
		Query<Employee> query = session.createQuery(hqlQuery,Employee.class);
		query.setParameter("myid",id);
		
		Employee e = query.uniqueResult();
		session.getTransaction().commit();
		session.close();
		return e;
   }
	
	public List<Employee> getAlldata() {
		Session session = factory.openSession();
		session.beginTransaction();
		
		String hqlQuery = "from Employee";
		
		Query<Employee> query =session.createQuery(hqlQuery,Employee.class);
		List<Employee> list = query.list();
		
		session.getTransaction().commit();
		session.close();
		return list;
	}
	
	
}





